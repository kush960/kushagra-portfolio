  <!-- Footer Section -->
  <div class="footer">
        <div class="content">
            &copy; Copyrights Reserved by Isratech
        </div>
    </div>
</body>
</html>