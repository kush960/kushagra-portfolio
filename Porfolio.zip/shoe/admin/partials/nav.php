<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="../admin.css">
</head>
<body>
    <header class="header">
        <div class="admin-navBar">
            <ul class="admin-navList">
                <li class="admin-navItem"><a href="http://localhost/shoe/" class="admin-navLink">
                    Home
                </a></li>
                <li class="admin-navItem"><a href="index.php" class="admin-navLink">
                    Database
                </a></li>
                <li class="admin-navItem"><a href="manage-admin.php" class="admin-navLink">
                    Admin
                </a></li>
            </ul>
        </div>
    </header>