<?php  include('partials/nav.php')  ?>

<div class="body">
        <div class="container">
            <div class="content">
                <h1 class="title">
                    ADMINISTRATORS
                </h1>
              <table>
                  <div class="tableContent">
                      <div>
                  <tr class="headers">
                      <th>Id</th>
                      <th>Full Name</th>
                      <th>Email</th>
                      <th>Action</th>
                  </tr>
                  </div>
                      <div>
                  <tr class="headers">
                      <td>1.</td>
                      <td> Isra</td>
                      <td>Isra@</td>
                      <td>Action</td>
                  </tr>
                  </div>
                   
                  
                  </div>
              </table>
                

               
            </div>
        </div>
    </div>

<?php    include('partials/footer.php')      ?>