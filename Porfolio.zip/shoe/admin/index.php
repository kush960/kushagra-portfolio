
<?php include('partials/nav.php')  ?>

    <div class="body">
        <div class="container">
            <div class="content">
                <h1 class="title">
                    DASHBOARD
                </h1>

                <div class="boxes">
                    <div class="box">
                        <h3 class="boxTitle">5</h3>
                        <h4 class="boxDesc">Admins</h4>
                    </div>
                    <div class="box">
                        <h3 class="boxTitle">4</h3>
                        <h4 class="boxDesc">Categories</h4>
                    </div>
                    <div class="box">
                        <h3 class="boxTitle">10</h3>
                        <h4 class="boxDesc">Orders</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include('partials/footer.php')  ?>
  